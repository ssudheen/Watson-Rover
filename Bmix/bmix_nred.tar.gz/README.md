This project contains the core back end logic for the Watson Rover Project. It has flows related to Watson Language Identification and Machine Translation services. 

The official name for this project in GBS Watson challenge is the "R2-D2 Project"

Please contact Sudheendra Sreedharamurthy (+91 8800 200 330) for any further details
